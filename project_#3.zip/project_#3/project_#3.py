"""

projekt_3.py: třetí projekt do Engeto Online Python Akademie

author: Daniel Eslami Ghayour

email: eslamidaniel@gmail.com

discord: DanielEG eslami.d

"""

import urllib.request
from bs4 import BeautifulSoup as soup
import re
import pandas as pd

def scraper(user_insert_url, file_name):
    response = urllib.request.urlopen(user_insert_url)
    html = response.read()
    page_soup = soup(html,'lxml')
    #geting codes of districts
    dis_codes = []
    for e in page_soup.findAll('td', {'class':'cislo'}):
        all_codes = re.findall(r'\d{6}', str(e))
        dis_codes.append(all_codes[::2])

    data_to_csv = pd.DataFrame(list(dis_codes))
    data_to_csv = data_to_csv.rename(columns={ 0 : 'code'})
    #geting district names
    dis_names = []
    for e in page_soup.findAll('td', {'class':'overflow_name'}):
        dis_name_half_done = str(e).split('">')
        dis_name_almost_done = str(dis_name_half_done[1::2]).split('<')
        dis_name = dis_name_almost_done[0].replace('[\'','')
        dis_names.append(dis_name)

    data_to_csv['location'] = dis_names

    VP = []

    district_table = 'https://volby.cz/pls/ps2017nss/ps311?xjazyk=CZ&xkraj=12&xobec='+str(data_to_csv['code'][0])+'&xvyber='+str(user_insert_url[-4::])
    response = urllib.request.urlopen(district_table)
    html = response.read()
    page_soup = soup(html,'lxml')
    #geting voting parties
    for e in page_soup.findAll('td', {'class':'overflow_name'}):
            VP_half_done = str(e).split('2">')
            VP_done = str(VP_half_done[1]).split('</td>')
            VP.append(VP_done[0])
    #timer for loops
    timer = len(data_to_csv['code'])
    x = 0
    registered = []
    envelopes = []
    valid = []
    votes = []
    while x < timer:
        #geting html
        district_table = 'https://volby.cz/pls/ps2017nss/ps311?xjazyk=CZ&xkraj=12&xobec='+str(data_to_csv['code'][x])+'&xvyber='+str(user_insert_url[-4::])
        response = urllib.request.urlopen(district_table)
        html = response.read()
        page_soup = soup(html,'lxml')
        #geting registred votes
        for e in page_soup.findAll('td', {'headers':'sa2'}):
            registered_half_done = str(e).split('2">')
            registered_almost_done = str(registered_half_done[1]).split('</td>')
            registered_one = registered_almost_done[0].replace('\xa0',' ')
            registered.append(registered_one)
        #geting number of envelopes
        for e in page_soup.findAll('td', {'headers':'sa5'}):
            envelopes_half_done = str(e).split('5">')
            envelopes_almost_done = str(envelopes_half_done[1]).split('</td>')
            envelopes_one = envelopes_almost_done[0].replace('\xa0',' ')
            envelopes.append(envelopes_one)
        #geting valid votes
        for e in page_soup.findAll('td', {'headers':'sa6'}):
            valid_half_done = str(e).split('6">')
            valid_almost_done = str(valid_half_done[1]).split('</td>')
            valid_one = valid_almost_done[0].replace('\xa0',' ')
            valid.append(valid_one)

        #first half of the votes from first table
        for e in page_soup.findAll('td', {'headers':'t1sb3'}):
            votes1_half_done = str(e).split('3">')
            votes1_almost_done = str(votes1_half_done[1]).split('</td>')
            votes.append(votes1_almost_done[0])
            
        #second half of the votes from second table
        for e in page_soup.findAll('td', {'headers':'t2sb3'}):
            votes2_half_done = str(e).split('3">')
            votes2_almost_done = str(votes2_half_done[1]).split('</td>')
            votes.append(votes2_almost_done[0])
        x += 1
    else:
        pass
    #getting rid of - from votes
    K =('-')
    votes = [i for i in votes if i != K]
    #puting registered, envelopes and valid to dataframe
    data_to_csv['registered'] = registered
    data_to_csv['envelopes'] = envelopes
    data_to_csv['valid'] = valid

    z = 0
    v = 0
    x = 0
    vote_parties_count = len(VP)

    #puting parties and votes into dataframe
    while z < len(votes):
        while v < vote_parties_count:
            data_to_csv.loc[x,VP[v]] = votes[z]
            z += 1
            v += 1
        else:
            v = 0
            x += 1
    #saving data
    data_to_csv.to_csv('project_#3/'+file_name)


scraper('https://volby.cz/pls/ps2017nss/ps32?xjazyk=CZ&xkraj=12&xnumnuts=7103','names.csv')